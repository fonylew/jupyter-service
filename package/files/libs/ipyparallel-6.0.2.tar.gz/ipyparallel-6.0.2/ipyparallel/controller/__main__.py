def main():
    from ipyparallel.apps import ipcontrollerapp as app
    app.launch_new_instance()
    
if __name__ == '__main__':
    main()
