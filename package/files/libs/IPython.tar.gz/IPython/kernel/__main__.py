if __name__ == '__main__':
    from IPython.kernel.zmq import kernelapp as app
    app.launch_new_instance()
