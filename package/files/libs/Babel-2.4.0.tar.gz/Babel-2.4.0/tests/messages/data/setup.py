#!/usr/bin/env python
# -*- coding: utf-8 -*-
# vim: sw=4 ts=4 fenc=utf-8
# =============================================================================
# $Id$
# =============================================================================
# $URL$
# $LastChangedDate$
# $Rev$
# $LastChangedBy$
# =============================================================================
# Copyright (C) 2006 Ufsoft.org - Pedro Algarvio <ufs@ufsoft.org>
#
# Please view LICENSE for additional licensing information.
# =============================================================================

# THIS IS A BOGUS PROJECT

from setuptools import setup, find_packages

setup(
    name = 'TestProject',
    version = '0.1',
    license = 'BSD',
    author = 'Foo Bar',
    author_email = 'foo@bar.tld',
    packages = find_packages(),
)
