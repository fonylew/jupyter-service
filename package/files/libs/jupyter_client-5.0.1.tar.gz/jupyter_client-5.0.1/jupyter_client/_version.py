version_info = (5, 0, 1)
__version__ = '.'.join(map(str, version_info))

protocol_version_info = (5, 1)
protocol_version = "%i.%i" % protocol_version_info
