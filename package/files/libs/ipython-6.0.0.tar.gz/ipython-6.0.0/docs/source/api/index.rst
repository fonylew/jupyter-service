.. _api-index:

###################
  The IPython API
###################

.. only:: html

   :Release: |version|
   :Date: |today|

.. include:: generated/gen.txt
