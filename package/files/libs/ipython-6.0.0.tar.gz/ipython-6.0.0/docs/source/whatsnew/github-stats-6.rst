Issues closed in the 6.x development cycle
==========================================

Issues closed in 6.0
--------------------

GitHub stats for 2017/04/10 - 2017/04/19 (milestone: 6.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 49 issues and merged 145 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A6.0+>`__

The following 34 authors contributed 176 commits.

* Adam Eury
* anantkaushik89
* Antonino Ingargiola
* Benjamin Ragan-Kelley
* Carol Willing
* Chilaka Ramakrishna
* chillaranand
* Denis S. Tereshchenko
* Diego Garcia
* fatData
* Fermi paradox
* fuho
* Grant Nestor
* Ian Rose
* Jeroen Demeyer
* kaushikanant
* Keshav Ramaswamy
* Matteo
* Matthias Bussonnier
* mbyt
* Michael Käufl
* michaelpacer
* Moez Bouhlel
* Pablo Galindo
* Paul Ivanov
* Piotr Przetacznik
* Rounak Banik
* sachet-mittal
* Srinivas Reddy Thatiparthy
* Tamir Bahar
* Thomas Hisch
* Thomas Kluyver
* Utkarsh Upadhyay
* Yuri Numerov
