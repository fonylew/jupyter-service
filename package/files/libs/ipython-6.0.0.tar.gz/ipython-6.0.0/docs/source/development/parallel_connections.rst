:orphan:

==============================================
Connection Diagrams of The IPython ZMQ Cluster
==============================================

IPython parallel has moved to ipyparallel -
see :ref:`ipyparallel:parallel_connections` for the documentation.
