.. _development_faq:

Developer FAQ
=============

1. How do I install a prerelease version such as a beta or release candidate?

.. code-block:: bash

    python -m pip install notebook --pre --upgrade
