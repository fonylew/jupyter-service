.. _parser-api:

Parser API
==========

.. module:: sphinx.parsers

.. autoclass:: Parser
