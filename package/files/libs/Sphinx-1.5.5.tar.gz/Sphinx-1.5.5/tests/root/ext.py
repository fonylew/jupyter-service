# Test extension module

def setup(app):
    app.add_config_value('value_from_ext', [], False)
