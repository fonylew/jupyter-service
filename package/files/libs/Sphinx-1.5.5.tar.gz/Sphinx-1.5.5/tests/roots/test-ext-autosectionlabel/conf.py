# -*- coding: utf-8 -*-

extensions = ['sphinx.ext.autosectionlabel']
master_doc = 'index'
