============================
Test double inheriting theme
============================
