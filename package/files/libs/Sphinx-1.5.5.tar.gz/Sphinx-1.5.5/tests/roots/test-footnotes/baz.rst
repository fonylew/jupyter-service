baz
===

Auto footnote number [#]_ in baz.rst

.. [#] footnote in baz
