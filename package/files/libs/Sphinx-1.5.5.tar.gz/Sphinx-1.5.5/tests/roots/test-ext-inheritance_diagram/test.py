# -*- coding: utf-8 -*-


class Foo(object):
    pass


class Bar(Foo):
    pass


class Baz(Bar):
    pass


class Qux(Foo):
    pass
