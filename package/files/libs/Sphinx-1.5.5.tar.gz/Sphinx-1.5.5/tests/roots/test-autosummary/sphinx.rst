Autosummary test
================

.. autosummary::
   :toctree: generated

   sphinx.application.Sphinx

.. currentmodule:: sphinx.application

.. autoclass:: TemplateBridge

   Basic test

   .. autosummary::

      render                    -- some ignored stuff goes here
      render_string             More ignored stuff

   Test with tildes

   .. autosummary::

      ~TemplateBridge.render
      ~TemplateBridge.render_string

   Methods:

  .. automethod:: render

  .. automethod:: render_string
