from dummy import *


def test():
    """Dummy function using dummy.*"""
    dummy_function()
